The images have been undistorted.

The image pair used in HW5 was IMG_8207 as image1.jpg and IMG_8229.jpg as image2.jpg.
